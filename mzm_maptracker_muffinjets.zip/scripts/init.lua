local variant = Tracker.ActiveVariantUID

Tracker:AddItems("items/unique.json")
Tracker:AddItems("items/settings.json")
Tracker:AddItems("items/bosses.json")

ScriptHost:LoadScript("scripts/logic.lua")

Tracker:AddMaps("maps/bettermaps.json")

Tracker:AddLocations("locations/brinstar.json")
Tracker:AddLocations("locations/chozodia.json")
Tracker:AddLocations("locations/crateria.json")
Tracker:AddLocations("locations/kraid.json")
Tracker:AddLocations("locations/norfair.json")
Tracker:AddLocations("locations/ridley.json")
Tracker:AddLocations("locations/tourian.json")

if (string.find(Tracker.ActiveVariantUID, "standard")) then
    Tracker:AddItems("items/normaltanks.json")
    Tracker:AddLayouts("layouts/tracker.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    ScriptHost:LoadScript("scripts/capturebadge.lua")

else if (string.find(Tracker.ActiveVariantUID, "hard")) then
    Tracker:AddItems("items/hardtanks.json")
    Tracker:AddLayouts("layouts/tracker.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    ScriptHost:LoadScript("scripts/capturebadge.lua")
end
end