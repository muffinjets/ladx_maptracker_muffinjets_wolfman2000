function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    amount = tonumber(amount)
    if not amount then
      return count > 0
    else
      return count == amount
    end
  end

function BeatKraid()
  if has("kraiditem") then
    return 1
  else
    return 0
  end
end

function BeatRidley()
  if has("ridleyitem") then
    return 1 
  else
    return 0
  end
end

function BeatBrain()
  if has("motherbrainitem") then
    return 1
  else
    return 0
  end
end

function ActivateUnknownItems()
  if has("charlieitem") or
  has("ObtainUnknownItems") then
    return 1
  else
    return 0
  end
end

function EnterChozodia()
  if EarlyChozodia() == 1 or BeatBrain() == 1 then
    return 1
  else
    return 0
  end
end

--REPLACEMENTS
function CanIBJ()
  if has("morph") and has("bombs") and has("IBJ") then
    return 1
  else
    return 0
  end
end

function ActiveSpace()
  if has("space") and ActivateUnknownItems() == 1 then
    return 1
  else
    return 0
  end
end

function ActiveGravity()
  if has("gravity") and ActivateUnknownItems() == 1 then
    return 1
  else
    return 0
  end
end

function ActivePlasma()
  if has("plasma") and ActivateUnknownItems() == 1 then
    return 1
  else
    return 0
  end
end

function HeatImmune()
  if ActiveGravity() == 1 or has("varia") then
    return 1
  else
    return 0
  end
end

function BallJump()
  if has("morph") and (has("hijump") or has("bomb")) then
    return 1
  else
    return 0
  end
end

function BallCannon()
  if has("morph") and has("bomb") then
    return 1
  else
    return 0
  end
end

function BallSpark()
  if has("morph") and has("speed") and has("hijump") then
    return 1
  else
    return 0
  end
end

function BlockChain()
  if has("morph") and (has("bomb") or has("power")) then
    return 1
  else
    return 0
  end
end

function BombBlock()
  if has("screw") or BlockChain() == 1 then
    return 1
  else 
    return 0
  end
end

function RedDoor()
  if has("missile") or has("supers") then
    return 1
  else
    return 0
  end
end

function MissileBlock()
  if has("missile") or has("supers") then
    return 1
  else 
    return 0
  end
end

function SortaHighTunnel()
  if CanIBJ == 1 or (has("grip") and has("morph")) then
    return 1
  else
    return 0
  end
end

function HighTunnel()
  if CanIBJ == 1 or (ActiveSpace() == 1 and has("grip") and has("morph")) then
    return 1
  else
    return 0
  end
end

function HighTunnelWithWall()
  if CanIBJ == 1 or ((ActiveSpace() == 1 or has("IWJ")) and has("grip") and has("morph")) then
    return 1
  else
    return 0
  end
end

function CanAWS()
  if has("AWS") and has("morph") and has("bomb") and has("grip") then
    return 1
  else
    return 0
  end
end

function CanSpaceJBJ()
  if has("SpaceJBJ") and has("morph") and has("bomb") and ActiveSpace == 1 then
    return 1
  else
    return 0
  end
end

function EarlyChozodia()
  if has("morph") and has("powerbombs") and ((has("speed") and (has("IWJ") or has("grip") or has("hijump"))) or (MissileBlock() == 1 and (CanIBJ() == 1 or ((BallJump() == 1 or has("screw")) and ActiveSpace() == 1)))) then
    return 1
  else
    return 0
  end
end

function RidleyLeftArea()
  if EnterRidley() == 1 and (has("supers") or (RidleyRightArea() == 1 and HighTunnel() == 1)) then
    return 1
  else
    return 0
  end
end

function RidleyRightArea()
  if RidleyLeftArea() == 1 or (EnterRidley() == 1 and has("missile") and (CanIBJ() == 1 or (has("grip") and (has("ice") or ActiveSpace() == 1)))) then
    return 1
  else
    return 0
  end
end

function RidleyCenterArea()
  if RidleyRightArea() == 1 and SortaHighTunnel() == 1 then
    return 1
  else
    return 0
  end
end

function EnterRidley()
  if RidleyShortcut() == 1 or NorfairCaterpillars() == 1 then
    return 1
  else
    return 0 
  end
end

function RidleyShortcut()
  if PastVine() == 1 and has("missile") and HighTunnelWithWall() == 1 then
    return 1
  else
    return 0
  end
end

function KraidToNorfair()
  if EnterKraid() == 1 and KraidAcidPit() == 1 and has("powerbombs") and has("screw") then
    return 1
  else
    return 0
  end
end

function HiJumpStatue() 
  if (RidleyShortcut() == 1 or (PastVine() == 1 and has("speed"))) and has("missile") then
    return 1
  else
    return 0
  end
end

function NorfairCaterpillars()
  if HeatedNorfair() == 1 and has("wave") and has("speed") then
    return 1
  else
    return 0
  end
end

function HeatedNorfair()
  if KraidToNorfair() == 1 or (HiJumpStatue() == 1 and (((has("energy", 2) or HeatImmune() == 1) and CanIBJ() == 1) or ((has("energy", 4) or HeatImmune() == 1) and has("speed")))) then
    return 1
  else
    return 0
  end
end

function EnterNorfair()
  if BlockChain() == 1 then
    return 1
  else
    return 0
  end
end

function EnterKraid()
  if BombBlock() == 1 then
    return 1
  else
    return 0
  end
end

function GetGrip()
  if EnterCrateria() == 1 and BallJump() == 1 then
    return 1
  else
    return 0
  end
end

function PastVine()
  if EnterNorfair() == 1 and (CanIBJ() == 1 or has("grip") or has("hijump") or has("speed")) and (has("RemoveVine") or GetGrip() == 1) then
    return 1
  else
    return 0
  end
end

function EnterCrateria()
  if EnterNorfair() == 1 and (has("bomb") or has("long") or has("missile") or has("powerbomb")) then
    return 1
  else
    return 0
  end
end

function EnterPirateShip()
  if EnterChozodia() == 1 and (CanIBJ() == 1 or ActiveSpace() == 1 or (has("IWJ") and (has("hijump") or has("ice")))) and BlockChain() == 1 then
    return 1
  else
    return 0
  end
end

function UpperPirateShip()
  if EnterPirateShip() == 1 and ((has("missiles") and (ActiveSpace() == 1 or CanIBJ() == 1)) or (has("missiles") and has("screw") and (has("IWJ") or ActiveSpace() == 1))) and SortaHighTunnel() == 1 and (has("bomb") or has("powerbomb", 4)) then
    return 1
  else
    return 0
  end
end

function Ziplines()
  if RedDoor() == 1 and BallCannon() == 1 and (has("IWJ") or CanIBJ() == 1 or ActiveSpace() == 1 or has("grip")) and SortaHighTunnel() == 1 then
    return 1
  else
    return 0
  end
end

function KraidAcidPit()
  if SortaHighTunnel() == 1 and BlockChain() == 1 and BallJump() == 1 and (CanAWS() == 1 or Ziplines() == 1 or ActiveSpace() == 1) then
    return 1
  else
    return 0
  end
end


--INDIVIDUAL CHECKS WITH COMPLEX LOGIC

function BrinstarSixteenThree()
  if BombBlock() == 1 and (RedDoor() == 1 and (ActiveSpace() == 1 or (has("ice") and has("hijump") ))) and (CanIBJ() == 1 or ActiveSpace() == 1 or has("hijump")) and BallJump() == 1 and (has("etank", 1) or HeatImmune() == 1) and (has("long") or has("wave") or has("bomb") or has("powerbombs") or has("missiles",25) or has("supers",10)) then
    return 1
  else
    return 0
  end
end

function CrateriaTwentyTwoTwo()
  if EnterCrateria() == 1 and has("speed") and (has("IWJ") or ActiveSpace() == 1) and (BallJump() == 1 or (ActiveSpace() == 1 and has("screw"))) then
    return 1
  else
    return 0
  end
end

function KraidSevenTwelve()
  if BeatKraid() == 1 and ((Ziplines() == 1 and (BallCannon() == 1 or (ActiveSpace() == 1 and has("speed") or (has("long") and has("wave") and ActivePlasma() == 1 and has("hijump")))) or (ActiveSpace() == 1 and has("grip") ))) then
    return 1
  else
    return 0
  end
end

function NorfairFourTwelve()
  if HeatedNorfair() == 1 and has("missile",15) and has("morph") and (has("bomb") and has("powerbombs") and has("wave")) and (ActiveGravity() == 1 or (has("varia") and has("etank", 5)) or has("etank", 10)) then
    return 1
  else
    return 0
  end
end

function NorfairEightSeven()
  if has("screw") and (has("hijumps") or has("ice") or ActiveSpace() == 1 or CanIBJ() == 1) and ((HeatedNorfair() == 1 and has("missiles") and (has("IWJ") or CanIBJ() == 1 or ActiveSpace() == 1 )) or (BeatRidley() == 1 and has("speed"))) then
    return 1
  else
    return 0
  end
end

function NorfairElevenSix() 
  if PastVine() == 1 and (has("speed") or has("screw")) and has("supers") and (HeatImmune() == 1 or (has("speed") and has("etank", 1)) or ((has("wave") or has("screw") and has("etank", 4)) or has("etank", 8)) and SortaHighTunnel() == 1 and has("bomb")) then
    return 1
  else
    return 0
  end
end

function Energy3()
  if has("etank", 3) then
    return 1
  else
    return 0
  end
end

function NorfairFourteenSix()
  if PastVine() == 1 and (has("speed") or has("screw")) and has("supers") and (HeatImmune() == 1 or (has("speed") and has("etank", 1)) or ((has("wave") or has("screw") and has("etank", 4) ) or has("etank", 8))) then
    return 1
  else
    return 0
  end
end

function NorfairFifteenTen()
  if HeatedNorfair() == 1 and has("supers") and (has("speed") or (has("morph") and (has("bombs") or has("powerbombs")))) and (CanIBJ() == 1 or (has("ice") and has("hijump")) or ActiveSpace() == 1) and ((CanIBJ() == 1 and has("hijump")) or (ActiveSpace() == 1 and has("grip")) or (has("ice") and (has("bomb") or has("grip")))) then
    return 1
  else
    return 0
  end
end

function NorfairSeventeenTen()
  if HeatedNorfair() == 1 and has("supers") and (has("speed") or (has("morph") and (has("bombs") or has("powerbombs")))) and (CanIBJ() == 1 or (has("ice") and has("hijump")) or ActiveSpace() == 1) then
    return 1
  else
    return 0
  end
end

function NorfairTwentyoneOne()
  if PastVine() == 1 and (has("bomb") or has("powerbomb",1) or has("missiles") or has("supers") or has("long") and (has("ice") or has("IWJ") or CanIBJ() == 1 or ActiveSpace() == 1)) then
    return 1
  else
    return 0
  end
end

function ChozodiaFourEighteen()
  if EnterCrateria() == 1 and has("powerbombs") and (MissileBlock() == 1 and (CanIBJ() == 1 or (BallJump() == 1 or has("screw") and ActiveSpace() == 1))) then
    return 1
  else
    return 0
  end
end

function ChozodiaElevenThirteen()
  if EnterChozodia() == 1 and MissileBlock() == 1 and BombBlock() == 1 and has("morph") and ((ActiveGravity() == 1 and SortaHighTunnel() == 1 and BallJump() == 1) or (has("IWJ") and has("hijump") and has("grip") and ((has("varia") and has("etank", 4)) or has("etank", 8)))) then
    return 1
  else
    return 0
  end
end

function ChozodiaTwentySeven()
  if EnterPirateShip() == 1 and ((has("missile", 5) and (has("ice") or has("hijump") or ActiveSpace() == 1 or CanIBJ() == 1)) or (has("missile", 1) and has("screw") and (has("IWJ") or ActiveSpace() == 1))) and has("morph") then
    return 1
  else
    return 0
  end
end