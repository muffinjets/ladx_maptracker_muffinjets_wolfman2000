function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    amount = tonumber(amount)
    if not amount then
      return count > 0
    else
      return count == amount
    end
  end
  
  
  -- Arbitrary Config Section

LADX_AUTOTRACKER_DEBUG = true

----------------------------

print("")
print("Active Auto-Tracker Configuration (totally not borrowing this from Rain (thank you  <3))")
print("---------------------------------------")
if LADX_AUTOTRACKER_DEBUG then
    print("Enable Debug Logging         ", "true")
end
print("---------------------------------------")
print("")

----------------------------------------------------------------
------------------------data------------------------------------
----------------------------------------------------------------
local inventoryItemVals = {
    [0x00] = "Nothing",
    [0x01] = "Sword",
    [0x02] = "Bombs",
    [0x03] = "Power bracelet",
    [0x04] = "Shield",
    [0x05] = "Bow",
    [0x06] = "Hookshot",
    [0x07] = "Fire rod",
    [0x08] = "Pegasus boots",
    [0x09] = "Ocarina",
    [0x0A] = "Feather",
    [0x0B] = "Shovel",
    [0x0C] = "Magic Powder",
    [0x0D] = "Boomrang"
}

local inventorySlotAdds = {
    {address = 0xDB00, name = "B Slot"},
    {address = 0xDB01, name = "A Slot"},
    {address = 0xDB02, name = "Inv 01"},
    {address = 0xDB03, name = "Inv 02"},
    {address = 0xDB04, name = "Inv 03"},
    {address = 0xDB05, name = "Inv 04"},
    {address = 0xDB06, name = "Inv 05"},
    {address = 0xDB07, name = "Inv 06"},
    {address = 0xDB08, name = "Inv 07"},
    {address = 0xDB09, name = "Inv 08"},
    {address = 0xDB0A, name = "Inv 09"},
    {address = 0xDB0B, name = "Inv 10"}
    -- {address = 0xDB0C, name = "LADXR Inv 11"},
    -- {address = 0xDB0D, name = "LADXR Inv 12"},
    -- {address = 0xDB0E, name = "LADXR Inv 13"},
    -- {address = 0xDB0F, name = "LADXR Inv 14"},
    
}

-- local dungeons = {
--     ["Tail Cave"] = {
--         ["smallKey"] {"D1SK", }, -- Should you even track small keys with how dumb LADX does?
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 3,
--         ["bigKey"] = {"D1BK", ,1}, -- Where's the Big Key address? What does "1" mean?
--         ["instrument"] = {"cello", 0xDB65, 0},  --What does the "0" mean? Uncollected?
--         ["chests"] = { --Which code?
--             [] = "Mini-Moldorm Ceiling Key"
--             [] = "Compass Chest"
--             [] = "Button"
--             [] = "Map Chest"
--             [] = "Chest Guarded by Spark"
--             [] = "Kill Mini-Moldorm"
--             [] = "Bombable Wall"
--             [] = "Roc's Feather"
--             [] = "Nightmare's Key" --Include subtitle?
--             [] = "Three-of-a-Kind"
--             [] = "Moldorm" --Cello is a hosted item
--         }
--     },
--     ["Bottle Grotto"] = {
--         ["smallKey"] {"D2SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 5,
--         ["bigKey"] = {"D2BK", ,1},
--         ["instrument"] = {"conch", 0xDB66, 0},
--         ["chests"] = {
--             [] = "Intro Chest",
--             [] = "Across the Gap",
--             [] = "Stalfos Ceiling Key",
--             [] = "Shy Guy/Compass Chest" -- Will the slash in the name be an issue?
--             [] = "Shy Guy Ceiling Key",
--             [] = "Surrounded by Blocks",
--             [] = "Button Across the Gaps",
--             [] = "Map Chest",
--             [] = "Ghost Room",
--             [] = "The Forgotten Chest",
--             [] = "Surrounded by Blocks Again",
--             [] = "Pols Voice, Keese, then Hooded Stalfos",
--             [] = "Mad Genie"
--         }
--     },
--     ["Key Cavern"] = {
--         ["smallKey"] {"D3SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 8,
--         ["bigKey"] = {"D3BK", ,1},
--         ["instrument"] = {"bell", 0xDB67, 0},
--         ["chests"] = {
--             [] = "East of Entrance",
--             [] = "North of Entrance",
--             [] = "Map Chest",
--             [] = "Zol Chest",
--             [] = "Kill the Stalfos and the Small Zol"
--             [] = "Stone Beak Chest",
--             [] = "West Ceiling Key",
--             [] = "South Ceiling Key",
--             [] = "Kill Zols",
--             [] = "Pairodd Ceiling Key",
--             [] = "West Ledge"
--             [] = "Dodongo Snakes",
--             [] = "East Ledge",
--             [] = "Green Bombites",
--             [] = "Red Bombites Ceiling Key",
--             [] = "Conveyor Keese Ceiling Key",
--             [] = "Slime Eye"
--         }

--     }.
--     ["Angler's Tunnel"] = {
--         ["smallKey"] {"D4SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 5,
--         ["bigKey"] = {"D4BK", ,1},
--         ["instrument"] = {"harp", 0xDB68, 0},
--         ["chests"] = {
--             [] = "Map Chest",
--             [] = "Stone Beak Chest",
--             [] = "East of Entrance",
--             [] = "East, then South of Entrance",
--             [] = "Eastern Lonely Chest",
--             [] = "First Watery Chest",
--             [] = "Second Watery Chest",
--             [] = "Small Key in the Hole",
--             [] = "Western Lonely Chest",
--             [] = "Zora's Flippers",
--             [] = "South of the Sparkly Tiles"
--             [] = "Ledge Chest",
--             [] = "Guarded by the Hooded Stalfos",
--             [] = "Angler Fish"
--         }

--     },
--     ["Catfish's Maw"] = {
--         ["smallKey"] {"D5SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 3,
--         ["bigKey"] = {"D5BK", ,1},
--         ["instrument"] = {"marimba", 0xDB69, 0},
--         ["chests"] = {
--             [] = "First Chest",
--             [] = "Compass Chest",
--             [] = "Ceiling Key Near Round 4",
--             [] = "Stone Beak",
--             [] = "Hookshot Over The Gaps",
--             [] = "Master Stalfos",
--             [] = "Nightmare's Key",
--             [] = "Hookshot Chest 1",
--             [] = "Hookshot Chest 2",
--             [] = "Hookshot Chest 3",
--             [] = "Round 3",
--             [] = "Slime Eel"

--         }

--     },
--     ["Face Shrine"] = {
--         ["smallKey"] {"D6SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 3,
--         ["bigKey"] = {"D6BK", ,1},
--         ["instrument"] = {"triangle", 0xDB6A, 0},
--         ["chests"] = {
--             [] = "Kill the Wizzrobes",
--             [] = "Lift the Elephant",
--             [] = "L-2 Power Bracelet",
--             [] = "Map Chest",
--             [] = "Stone Beak",
--             [] = "Compass Chest",
--             [] = "North Ledge Crystal Blocks Ceiling Key",
--             [] = "West Horsehead",
--             [] = "D6 Raft Minigame Island",
--             [] = "Blade Trap Ledge",
--             [] = "Moist Chest",
--             [] = "Tile Ceiling Key",
--             [] = "East Horsehead",
--             [] = "Pot Chest",
--             [] = "Facade"
--         }

--     },
--     ["Eagle's Tower"] = {
--         ["smallKey"] {"D7SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 3,
--         ["bigKey"] = {"D7BK", ,1},
--         ["instrument"] = {"organ", 0xDB6B, 0},
--         ["chests"] = {
--             [] = "Like Like Ceiling Key",
--             [] = "Mirror Shield",
--             [] = "Top-Right Corner",
--             [] = "Horseheads",
--             [] = "Three-of-a-Kind",
--             [] = "Hinox Ceiling Key",
--             [] = "Top-Left Corner",
--             [] = "Stone Beak",
--             [] = "Hookshottable Chest",
--             [] = "Grim Creeper",
--             [] = "Conveyor Horseheads",
--             [] = "Evil Eagle"
--         }

--     },
--     ["Turtle Rock"] = {
--         ["smallKey"] {"D8SK", },
--         ["currentSmallKeys"] = 0,
--         ["maxSmallKeys"] = 7,
--         ["bigKey"] = {"D8BK", ,1},
--         ["instrument"] = {"drum", 0xDB6C, 0},
--         ["chests"] = {
--             [] = "West Directional Block",
--             [] = "Light Torches",
--             [] = "Guarded by Sparks",
--             [] = "Vire Ceiling Key",
--             [] = "South of Rolling Bones",
--             [] = "East of Pot Room",
--             [] = "Southwestern Directional Block Ceiling Key",
--             [] = "Guarded by Ropes",
--             [] = "Map Chest",
--             [] = "Shoot the Eye Statue Ceiling Key",
--             [] = "West of Eye Statue",
--             [] = "D8 - Mountain Summit"
--             [] = "Dodongo Snakes",
--             [] = "Gibdo Ceiling Key",
--             [] = "Northwest of Dodongo Snakes",
--             [] = "Chest on Ledge",
--             [] = "North of Cue Ball Directional Block",
--             [] = "Blaino",
--             [] = "Hot Head"

--         }

--     },
--     ["Color Dungeon"] = { -- Key logic isn't tracked, dungeon doesn't have an instrument
--         ["chests"] = {
--             [] = "Bomb the Color Puzzle South Wall",
--             [] = "First Color Puzzle",
--             [] = "Red-Green Orb Enemy Chest",
--             [] = "South-East One-Way Loop Chest",
--             [] = "Red-Blue-Yellow 2x2 Color Puzzle",
--             [] = "Giant Zol",
--             [] = "Kill all the Zols in the Pot Room",
--             [] = "Red-Blue-Green-Green Orb Enemy Room",
--             [] = "Evil Orb",
--             [] = "Red/Blue Mail"
--         }

--     }
-- }


----------------------------------------------------------------
-------------------------uhh code I guess-----------------------
----------------------------------------------------------------
print("successfully started loading autotracking.lua")

U8_READ_CACHE = {}

function ReadU8(segment, address)
    if (not U8_READ_CACHE[address]) then
        U8_READ_CACHE[address] = segment:ReadUInt8(address)
    end

    return U8_READ_CACHE[address]
end


function updateItem(segment, itemRef, memLoc, offset)
	local item = Tracker:FindObjectForCode(itemRef)
	if item then
		if item.Owner.ModifiedByUser then
			return
		end

		if(ReadU8(segment, memLoc) & (1 << offset) > 0) then
			item.Active = true
		else
			item.Active = false
		end
		return item.Active
	else
		error("could not find item: "..itemRef)
	end
end

function checkBButtonForSword(segment)
    local item = Tracker:FindObjectForCode("sword")
    if segment:ReadUInt8(0xDB00) == 0x01 then
        print("success")
    else
        print("no")
    end
end

function checkInventoryForSword(segment)
    local item = Tracker:FindObjectForCode("sword1")
    if segment:ReadUInt8(0xDB00) == 0x01 then
        updateItem(segment, "sword1")
    else
        print("nah fam")
    end
end
        

ScriptHost:AddMemoryWatch("sword on B check", 0xDB00, 0x0C, checkInventoryForSword, 1000)


-- for variable=valueRangeStart,valueRangeEnd,stepAmount do
--     something
-- end

-- for i=1, f(x) do
--     print(i)
-- end
