Added in update 1.4.9
Edited in update 1.5.2


Hey!

Thanks for checking out the backend of my map tracker.  

Whether you're here to take the image files or if you're here to learn how to create your own map tracker, you're welcome to take anything you want.

If you are a pack creator, feel free to message me on Discord at MuffinJets#7751*.  The EmoTracker Discord server can be a little intimidating if you don't know what you're doing, so it's completely reasonable to not want to ask for help there.

If you're using the Export Overrides tool to customize this pack to how you want, that's awesome!  I'd love to know what you've changed so I can possibly implement it into the next update, I'm always open to suggestions.


No matter why you're seeing this message, I'm glad you're here and I hope you have a good time playing the LADX randomizer.

Thank you,
MuffinJets

*During holidays, I sometimes change my username to different names like MuffinSpooks or MuffinBells.  If you can't find my username after that, look for me in the EmoTracker server or in the LADX speedrunning/randomizer servers.

