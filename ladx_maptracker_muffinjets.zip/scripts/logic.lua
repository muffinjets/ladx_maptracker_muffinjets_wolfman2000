function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    amount = tonumber(amount)
    if not amount then
      return count > 0
    else
      return count == amount
    end
  end


function can_break_grass()
    if has("sword") 
    or has("lift1") 
    or has("powder") 
    or has("rod") 
    then
        return 1
    else
        return 0
    end
end

function can_access_swamp()
    if can_break_grass() > 0 and
    has("feather")
    or has("lift1") then
        return 1
    else
      return 0
  end
end

function can_break_swamp_flowers()
  if can_access_swamp() > 0 and
  has("rod") or has("hookshot") or has("chomp") then
    return 1
  else
    return 0
  end
end

function can_open_egg()
  if has("ocarina")
  and has("ballad")
  and has("cello")
  and has("conch")
  and has("bell")
  and has("harp")
  and has("marimba")
  and has("triangle")
  and has("organ")
  and has("drum") then
    return 1
  else
    return 0
  end
end

function exactly_five_shells()
  if has("shells", 5) then
    return 1
  else
    return 0
  end
end

function exactly_ten_shells()
  if has("shells", 10) then
    return 1
  else
    return 0
  end
end

function can_bomb_trigger_fisherman()
  if has("bombs")
  and has("pineapple")
  and has("flippers")
  and has("lift1") then
    return 1
  else
    return 0
  end
end

function can_leave_mabe()
  if has("lift1")
  and has("flippers")
  or
  has("lift1")
  and has("boots")
  and has("setting_connectormods_off")
  or
  has("lift1")
  and has("hookshot")
  or
  has("lift1")
  and has("setting_connectormods_on")
  or
  can_break_grass() > 0
  and has("feather")
  and has("hookshot")
  and has("flippers")
  or
  has("boots")
  and has("feather")
  and has("flippers")
  or
  has("boots")
  and has("feather")
  and has("setting_connectormods_off")
  or
  has("boots")
  and has("feather")
  and has("hookshot")
  then
    return 1
  else
    return 0
  end
end

function can_attack()
  if has("sword")
  or has("powder")
  or has("bombs")
  or has("bow")
  or has("hookshot")
  or has("rod") 
  then
    return 1
  else
    return 0
  end
end

function west_tal()
  if has("setting_overworldmods_on")
  and has("hookshot")
  or
  has("setting_overworldmods_off")
  and has("flippers")
  and has("boots") then
    return 1
  else
    return 0
  end
end


function kill_wizz()
  if has("bow")
  or has("bombs")
  or has("sword2")
  or has("rod")
  or has("hookshot") and has("lift1") then
    return 1
  else
    return 0
  end
end

function kill_vire()
  if has("powder")
  or has("rod")
  or has("sword2") then
    return 1
  else
    return 0
  end
end
