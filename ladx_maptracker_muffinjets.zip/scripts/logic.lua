function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    amount = tonumber(amount)
    if not amount then
      return count > 0
    else
      return count == amount
    end
  end


function can_break_grass()
    if has("sword") 
    or has("lift1") 
    or has("powder") 
    or has("rod") 
    then
        return 1
    else
        return 0
    end
end

function can_access_swamp()
    if can_break_grass() > 0 and
    has("feather")
    or has("lift1") then
        return 1
    else
      return 0
  end
end

function can_break_swamp_flowers()
  if can_access_swamp() > 0 and
  has("rod") or has("hookshot") or has("chomp") then
    return 1
  else
    return 0
  end
end

function can_open_egg()
  if has("ocarina")
  and has("ballad")
  and has("cello")
  and has("conch")
  and has("bell")
  and has("harp")
  and has("marimba")
  and has("triangle")
  and has("organ")
  and has("drum") then
    return 1
  else
    return 0
  end
end

function exactly_five_shells()
  if has("shells", 5) then
    return 1
  else
    return 0
  end
end

function exactly_ten_shells()
  if has("shells", 10) then
    return 1
  else
    return 0
  end
end

function random_shell_range()
  if has("shells", 11) or
  has("shells", 12) or
  has("shells", 13) or
  has("shells", 14) or
  has("shells", 15) or
  has("shells", 16) or
  has("shells", 17) or
  has("shells", 18) or
  has("shells", 19) or
  has("shells", 20) or
  has("shells", 21) or
  has("shells", 22) then
    return 1
  else
    return 0
  end
end

function can_bomb_trigger_fisherman()
  if has("bombs")
  and has("pineapple")
  and has("flippers")
  and has("lift1") then
    return 1
  else
    return 0
  end
end

function can_leave_mabe()
  if has("lift1")
  and has("flippers")
  or
  has("lift1")
  and has("boots")
  and has("setting_connectormods_off")
  or
  has("lift1")
  and has("hookshot")
  or
  has("lift1")
  and has("setting_connectormods_on")
  or
  can_break_grass() > 0
  and has("feather")
  and has("hookshot")
  and has("flippers")
  or
  has("boots")
  and has("feather")
  and has("flippers")
  or
  has("boots")
  and has("feather")
  and has("setting_connectormods_off")
  or
  has("boots")
  and has("feather")
  and has("hookshot")
  then
    return 1
  else
    return 0
  end
end

function can_attack()
  if has("sword")
  or has("powder")
  or has("bombs")
  or has("bow")
  or has("hookshot")
  or has("rod") 
  then
    return 1
  else
    return 0
  end
end

function west_tal()
  if has("setting_overworldmods_on")
  and has("hookshot")
  or
  has("setting_overworldmods_off")
  and has("flippers")
  and has("boots") then
    return 1
  else
    return 0
  end
end


function kill_wizz()
  if has("bow")
  or has("bombs")
  or has("sword2")
  or has("rod")
  or has("hookshot") and has("lift1") then
    return 1
  else
    return 0
  end
end

function kill_vire()
  if has("powder")
  or has("rod")
  or has("sword2") then
    return 1
  else
    return 0
  end
end

function has_slime_key()
  if has("slime") then 
    return 1
  else
    return 0
  end
end

function not_slime_key()
  if has_slime_key() > 0 then
    return 0
  else
    return 1
  end
end

function has_armor()
  if has("armor2") then
    return 1
  else
    return 0
  end
end

function not_armor()
  if has_armor() > 0 then
    return 0
  else
    return 1
  end
end

function has_cello()
  if has("cello") then
    return 1
  else
    return 0
  end
end

function not_cello()
  if has_cello() > 0 then
    return 0
  else
    return 1
  end
end

function has_conch()
  if has("conch") then
    return 1
  else
    return 0
  end
end

function not_conch()
  if has_conch() > 0 then
    return 0
  else
    return 1
  end
end

function has_bell()
  if has("bell") then
    return 1
  else
    return 0
  end
end

function not_bell()
  if has_bell() > 0 then
    return 0
  else
    return 1
  end
end

function has_harp()
  if has("harp") then
    return 1
  else
    return 0
  end
end

function not_harp()
  if has_harp() > 0 then
    return 0
  else
    return 1
  end
end

function has_marimba()
  if has("marimba") then
    return 1
  else
    return 0
  end
end

function not_marimba()
  if has_marimba() > 0 then
    return 0
  else
    return 1
  end
end

function has_triangle()
  if has("triangle") then
    return 1
  else
    return 0
  end
end

function not_triangle()
  if has_triangle() > 0 then
    return 0
  else
    return 1
  end
end

function has_organ()
  if has("organ") then
    return 1
  else
    return 0
  end
end

function not_triangle()
  if has_triangle() > 0 then
    return 0
  else
    return 1
  end
end

function has_drum()
  if has("drum") then
    return 1
  else
    return 0
  end
end

function not_drum()
  if has_drum() > 0 then
    return 0
  else
    return 1
  end
end