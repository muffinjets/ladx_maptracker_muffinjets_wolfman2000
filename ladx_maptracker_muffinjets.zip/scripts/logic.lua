function has(item, amount)
    local count = Tracker:ProviderCountForCode(item)
    amount = tonumber(amount)
    if not amount then
      return count > 0
    else
      return count == amount
    end
  end


function can_break_grass()
    if has("sword") 
    or has("lift1") 
    or has("powder") 
    or has("rod") 
    then
        return 1
    else
        return 0
    end
end

function can_access_swamp()
    if can_break_grass() > 0 and
    has("feather")
    or has("lift1") then
        return 1
    else
      return 0
  end
end

function can_break_swamp_flowers()
  if can_access_swamp() > 0 and
  has("rod") or has("hookshot") or has("chomp") then
    return 1
  else
    return 0
  end
end

function can_open_egg()
  if has("ocarina")
  and has("ballad")
  and has("cello")
  and has("conch")
  and has("bell")
  and has("harp")
  and has("marimba")
  and has("triangle")
  and has("organ")
  and has("drum") then
    return 1
  else
    return 0
  end
end

function exactly_five_shells()
  if has("shells", 5) then
    return 1
  else
    return 0
  end
end

function exactly_ten_shells()
  if has("shells", 10) then
    return 1
  else
    return 0
  end
end

function can_bomb_trigger_fisherman()
  if has("bombs")
  and has("pineapple")
  and has("flippers")
  and has("lift1") then
    return 1
  else
    return 0
  end
end

function can_leave_mabe()
  if has("lift1")
  and has("flippers")
  or
  has("lift1")
  and has("boots")
  and has("setting_connectormods_off")
  or
  has("lift1")
  and has("hookshot")
  or
  has("lift1")
  and has("setting_connectormods_on")
  or
  can_break_grass() > 0
  and has("feather")
  and has("hookshot")
  and has("flippers")
  or
  has("boots")
  and has("feather")
  and has("flippers")
  or
  has("boots")
  and has("feather")
  and has("setting_connectormods_off")
  or
  has("boots")
  and has("feather")
  and has("hookshot")
  then
    return 1
  else
    return 0
  end
end

function can_attack()
  if has("sword")
  or has("powder")
  or has("bombs")
  or has("bow")
  or has("hookshot")
  or has("rod") 
  then
    return 1
  else
    return 0
  end
end

function west_tal()
  if has("setting_overworldmods_on")
  and has("hookshot")
  or
  has("setting_overworldmods_off")
  and has("flippers")
  and has("boots") then
    return 1
  else
    return 0
  end
end

function D0SK1()
  if has("D0SK", 1) then
    return 1
  else
    return 0
  end
end

function D0SK2()
  if has("D0SK", 2) then
    return 1
  else
    return 0
  end
end

function D0SK3()
  if has("D0SK", 3) then
    return 1
  else
    return 0
  end
end

function D1SK1()
  if has("D1SK", 1) then
    return 1
  else
    return 0
  end
end

function D1SK2()
  if has("D1SK", 2) then
    return 1
  else
    return 0
  end
end

function D1SK3()
  if has("D1SK", 3) then
    return 1
  else
    return 0
  end
end

function D2SK1()
  if has("D2SK", 1) then
    return 1
  else
    return 0
  end
end

function D2SK2()
  if has("D2SK", 2) then
    return 1
  else
    return 0
  end
end

function D2SK3()
  if has("D2SK", 3) then
    return 1
  else
    return 0
  end
end

function D2SK4()
  if has("D2SK", 4) then
    return 1
  else
    return 0
  end
end

function D3SK1()
  if has("D3SK", 1) then
    return 1
  else
    return 0
  end
end

function D3SK2()
  if has("D3SK", 2) then
    return 1
  else
    return 0
  end
end

function D3SK3()
  if has("D3SK", 3) then
    return 1
  else
    return 0
  end
end

function D3SK4()
  if has("D3SK", 4) then
    return 1
  else
    return 0
  end
end

function D3SK5()
  if has("D3SK", 5) then
    return 1
  else
    return 0
  end
end

function D3SK6()
  if has("D3SK", 6) then
    return 1
  else
    return 0
  end
end

function D3SK7()
  if has("D3SK", 7) then
    return 1
  else
    return 0
  end
end

function D3SK8()
  if has("D3SK", 8) then
    return 1
  else
    return 0
  end
end