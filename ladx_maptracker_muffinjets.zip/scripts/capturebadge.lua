CaptureBadgeSections = {

    --List out all of the locations that can be capturable

    --Format: 
    --"@code - Title of Check/Flavor Text on Check"

    --Tal Tal Mountain Range
    "@NextToAccess - Next to Mountain Access/Bomb the Alcove on the South Wall",
    "@AccessInterior - Mountain Access/Interior",
    "@RoosterKeyCave - Rooster Key Cave/Just Be Glad Those Rocks Are Here",
    "@5ChestGame - 5 Chest Game/Bomb the Dry Spot. You only have to open one.",
    "@AfterChestGame - After Chest Game/Chest on Ledge",

    --Goponga Swamp Area
    "@RemoteCaveLeft - Remote Cave/Left Chest",
    "@RemoteCaveRight - Remote Cave/Right Chest",
    "@SwampChest - Swamp Chest/Swamp Chest",


    --Mysterious Woods
    "@NorthofRacoon - North of Racoon/Chest",
    "@HookshotCave - Hookshot Cave/Chest",
    "@WoodsTunnelSkulls - Mysterious Woods Tunnel/Lift the Skulls",
    "@RightOfEntrance - Right of Entrance/Chest",
    "@HeartPieceOfShame - Surrounded by Holes/Heart Piece of Shame",

    --Mabe Village
    "@DreamShrineLeft - Dream Shrine/Left Chest",
    "@DreamShrineRight - Dream Shrine/Right Chest",

    --Ukuku Prairie
    "@GraveyardConnector - Graveyard Connector Cave/Across the Pits",
    "@BootsBombCave - Boots 'n' Bomb Cave/Boots Chest",
    "@RichardCave - Underneath Richard's Villa/In the Cave",

    --Animal Village
    "@BombArrowCave - Bomb Arrow Cave/Chest",

    --Rapids Ride
    "@Rapids1 - Rapids Ride/First Chest",
    "@Rapids2 - Rapids Ride/Second Chest",


    --D1
    "@D1BK - Nightmare's Key/On the Ledge",

    --D2
    "@D2Intro - Intro Chest/Surrounded by Pots",
    "@D2Gap - Across the Gap/Across the Gap",

    --D3
    "@D3Intro - East of Entrance/Past the Crystals",
    "@D3Miniboss - Dodongo Snakes/Feed them Bombs",
    "@D3EastLedge - East Ledge/East Ledge",

    --D4
    "@D4EastSouth - East, then South of Entrance/Kill the Tektites to leave",
    "@D4EastLonely - Eastern Lonely Chest/Missing its partner.",
    "@D4Ledge - Ledge Chest/Up on the ledge",
    "@D4Watery1 - First Watery Chest/First of a set",
    "@D4Watery2 - Second Watery Chest/Second in the set",
    "@D4WestLonely - Western Lonely Chest/Missing its partner.",

    --D5
    "@D5Intro - Intro Chest/Hookshottable Chest",
    "@D5Gaps - Hookshot over the Gaps/Chest",
    "@D51 - Hookshot Chest 1/Chest",
    "@D52 - Hookshot Chest 2/Chest",
    "@D53 - Hookshot Chest 3/Chest",
    "@D5BK - Nightmare's Key/Swim here",

    --D6
    "@D6Rapids - D6 Raft Minigame Island/Chest",
    "@D6BehindLift - Lift the Elephant/Chest"
}

CaptureBadgeCache = {}

function tracker_on_accessibility_updated()
	for i,section in pairs(CaptureBadgeSections) do
		local target = Tracker:FindObjectForCode(section)
		-- Has the captured item for this section changed since last update
		if target.CapturedItem ~= CaptureBadgeCache[target] then
			-- Does the location that owns this section already have a badge, if so remove it
			if CaptureBadgeCache[target.Owner] then
				target.Owner:RemoveBadge(CaptureBadgeCache[target.Owner])
				CaptureBadgeCache[target.Owner] = nil
				CaptureBadgeCache[target] = nil
			end
			-- Check if a captured item exists, add as badge to the sections owner if it does
			if target.CapturedItem then
				CaptureBadgeCache[target.Owner] = target.Owner:AddBadge(target.CapturedItem.PotentialIcon)
				CaptureBadgeCache[target] = target.CapturedItem
			end
		end
	end
end