CaptureBadgeCache = {}

function tracker_on_accessibility_updated()
    for i,section in pairs(CaptureBadgeSections) do
        local target = Tracker:FindObjectForCode(section)
        -- Has the captured item for this section changed since last update
        if target == nil then
            print("Failed to resolve " .. section .. " please check for typos.")
        elseif target.CapturedItem ~= CaptureBadgeCache[target] then
            -- Does the location that owns this section already have a badge, if so remove it
            if CaptureBadgeCache[target.Owner] then
                target.Owner:RemoveBadge(CaptureBadgeCache[target.Owner])
                CaptureBadgeCache[target.Owner] = nil
                CaptureBadgeCache[target] = nil
            end
            -- Check if a captured item exists, add as badge to the sections owner if it does
            if target.CapturedItem then
                CaptureBadgeCache[target.Owner] = target.Owner:AddBadge(target.CapturedItem.PotentialIcon)
                CaptureBadgeCache[target] = target.CapturedItem
            end
        end
    end
end

--If you want to use this code for your tracker, copy-paste all of the code above into it's own lua file (like you see here)


CaptureBadgeSections = {

    --List out all of the locations that can be capturable

    --Format: 
    --"@Title of Check/Flavor Text on Check"
    
    "@Top of D8 Left Side/If the path is a dead end, check it.  If not, mark it.",
    "@Turtle Rock/If the path is a dead end, check it.  If not, mark it.",
    "@Telephone Booth near D8/If the path is a dead end, check it.  If not, mark it.",
    "@Top of D8 Right Side/If the path is a dead end, check it.  If not, mark it.",
    "@Top of West Tal Tal/If the path is a dead end, check it.  If not, mark it.",
    "@Cave Near Flamethrower/If the path is a dead end, check it.  If not, mark it.",
    "@Under the Rock/If the path is a dead end, check it.  If not, mark it.",
    "@Bottom of West Tal Tal/If the path is a dead end, check it.  If not, mark it.",
    "@Mountain Access/If the path is a dead end, check it.  If not, mark it.",
    "@Path to West Tal Tal/If the path is a dead end, check it.  If not, mark it.",
    --"@Central Tal Tal Left Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Central Tal Tal Right Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Path to Papahl/If the path is a dead end, check it.  If not, mark it.",
    "@Near Papahl/If the path is a dead end, check it.  If not, mark it.",
    "@Rooster Man's House/If the path is a dead end, check it.  If not, mark it.",
    "@Rooster Cave/If the path is a dead end, check it.  If not, mark it.",
    --"@Above the 5 Chest Game/If the path is a dead end, check it.  If not, mark it.",
    "@Before 5 Chest Game/If the path is a dead end, check it.  If not, mark it.",
    "@After 5 Chest Game/If the path is a dead end, check it.  If not, mark it.",
    "@Up the Stairs/If the path is a dead end, check it.  If not, mark it.",
    "@Eagle's Tower/If the path is a dead end, check it.  If not, mark it.",
    "@East Tal Tal Left Cave/If the path is a dead end, check it.  If not, mark it.",
    "@East Tal Tal Right Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Near D7/If the path is a dead end, check it.  If not, mark it.",
    "@Path to D7/If the path is a dead end, check it.  If not, mark it.",
    "@Great Fairy Cave Near D7/If the path is a dead end, check it.  If not, mark it.",
    "@I'm running out of unique names for these caves/If the path is a dead end, check it.  If not, mark it.",
    "@Remote Cave Left Side/If the path is a dead end, check it.  If not, mark it.",
    "@Remote Cave Right Side/If the path is a dead end, check it.  If not, mark it.",
    "@Mr. Wright's House/If the path is a dead end, check it.  If not, mark it.",
    "@Swamp Telephone Booth/If the path is a dead end, check it.  If not, mark it.",
    "@Bottle Grotto/If the path is a dead end, check it.  If not, mark it.",
    "@Moblin's Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Camera Shop/If the path is a dead end, check it.  If not, mark it.",
    "@Beta Cave/You might have this cave turned off. Check your settings.",
    "@Manbo's Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Angler's Tunnel/If the path is a dead end, check it.  If not, mark it.",
    "@Staircase Out of D4/If the path is a dead end, check it.  If not, mark it.",
    --"@Damp Cave/If the path is a dead end, check it.  If not, mark it.",
    "@North of Raft Minigame Hut/If the path is a dead end, check it.  If not, mark it.",
    "@Mysterious Woods Western Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Mysterious Woods Northern Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Under the Rock in Mysterious Woods/If the path is a dead end, check it.  If not, mark it.",
    "@Mysterious Woods Southern Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Crazy Tracy's Hut/If the path is a dead end, check it.  If not, mark it.",
    "@Witch's Hut/If the path is a dead end, check it.  If not, mark it.",
    "@West Graveyard Staircase/If the path is a dead end, check it.  If not, mark it.",
    "@East Graveyard Staircase/If the path is a dead end, check it.  If not, mark it.",
    "@Color Dungeon/If the path is a dead end, check it.  If not, mark it.",
    "@Kanalet Castle Back Door/If the path is a dead end, check it.  If not, mark it.",
    "@Kanalet Castle Telephone Booth/If the path is a dead end, check it.  If not, mark it.",
    "@Outside Kanalet Castle Back Door/If the path is a dead end, check it.  If not, mark it.",
    "@Kanalet Castle Front Door/If the path is a dead end, check it.  If not, mark it.",
    "@Top of the Castle Central Entrance/If the path is a dead end, check it.  If not, mark it.",
    "@Top of the Castle Left Entrance/If the path is a dead end, check it.  If not, mark it.",
    "@Kanalet Castle cave past the holes/If the path is a dead end, check it.  If not, mark it.",
    "@Madam MeowMeow's House/If the path is a dead end, check it.  If not, mark it.",
    "@Drop into the Well/If the path is a dead end, check it.  If not, mark it.",
    "@Town Tool Shop/If the path is a dead end, check it.  If not, mark it.",
    "@Weathercock/If the path is a dead end, check it.  If not, mark it.",
    "@Dream Shrine/If the path is a dead end, check it.  If not, mark it.",
    "@Quadruplet's House - Right Side/If the path is a dead end, check it.  If not, mark it.",
    "@Quadruplet's House - Left Side/If the path is a dead end, check it.  If not, mark it.",
    "@Trendy Game/If the path is a dead end, check it.  If not, mark it.",
    "@Telephone Booth in Town/If the path is a dead end, check it.  If not, mark it.",
    "@Ulira's House/If the path is a dead end, check it.  If not, mark it.",
    "@Town Library/If the path is a dead end, check it.  If not, mark it.",
    "@Marin and Tarin's House/If the path is a dead end, check it.  If not, mark it.",
    "@Totally Stable and Normal Doghouse/If the path is a dead end, check it.  If not, mark it.",
    "@Telephone Booth near Town/If the path is a dead end, check it.  If not, mark it.",
    "@East of Town Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Key Cavern/If the path is a dead end, check it.  If not, mark it.",
    "@Boots 'n' Bomb Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Great Fairy Near Town/If the path is a dead end, check it.  If not, mark it.",
    "@Telephone Booth in Central Koholint/If the path is a dead end, check it.  If not, mark it.",
    "@Seashell Mansion/If the path is a dead end, check it.  If not, mark it.",
    "@Staircase West of the River/If the path is a dead end, check it.  If not, mark it.",
    --"@Martha's Bay Top of Cliff/If the path is a dead end, check it.  If not, mark it.",
    "@Martha's Bay Bottom of Cliff/If the path is a dead end, check it.  If not, mark it.",
    "@Martha's Bay Bottom of Cliff, but also South/If the path is a dead end, check it.  If not, mark it.",
    "@Staircase East of the River/If the path is a dead end, check it.  If not, mark it.",
    "@Face Shrine/If the path is a dead end, check it.  If not, mark it.",
    "@Cave near D6/If the path is a dead end, check it.  If not, mark it.",
    "@Great Fairy Near D6/If the path is a dead end, check it.  If not, mark it.",
    "@Armos Island/If the path is a dead end, check it.  If not, mark it.",
    "@Cave Near Waterfall/If the path is a dead end, check it.  If not, mark it.",
    "@Southern Shrine/If the path is a dead end, check it.  If not, mark it.",
    "@Under a certain Armos/If the path is a dead end, check it.  If not, mark it.",
    "@Catfish's Maw/If the path is a dead end, check it.  If not, mark it.",
    "@Richard's Villa/If the path is a dead end, check it.  If not, mark it.",
    "@Pothole Field/If the path is a dead end, check it.  If not, mark it.",
    "@Signpost Maze Staircase/If the path is a dead end, check it.  If not, mark it.",
    "@Tail Cave/If the path is a dead end, check it.  If not, mark it.",
    --"@Mermaid Statue Staircase/If the path is a dead end, check it.  If not, mark it.",
    --"@Under the Bridge/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village Telephone Booth/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village - Lefter House/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village - Left House/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village - Right House/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village - Righter House/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village - Just as Right as the one above/If the path is a dead end, check it.  If not, mark it.",
    "@Animal Village - Bombable Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Lanmola Cave/You might have this cave turned off.  Check your settings.",
    "@Desert Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Sale's Hut/If the path is a dead end, check it.  If not, mark it.",
    "@Beach Bombable Cave/If the path is a dead end, check it.  If not, mark it.",
    "@Staircase surrounded by Bushes/If the path is a dead end, check it.  If not, mark it.",
    "@Martha's Bay Telephone Booth/If the path is a dead end, check it.  If not, mark it.",
    "@Martha's Bay Overworld Tunnel Right Side/If the path is a dead end, check it.  If not, mark it.",
    "@Martha's Bay Overworld Tunnel Left Side/If the path is a dead end, check it.  If not, mark it.",
    "@House by the Bay/If the path is a dead end, check it.  If not, mark it.",
    "@Fall in a hole in the Rooster Cave/You might have this cave turned off. Check your settings.",
    "@Cave Near Angler Keyhole/If the path is a dead end, check it.  If not, mark it."
    
    
    
}