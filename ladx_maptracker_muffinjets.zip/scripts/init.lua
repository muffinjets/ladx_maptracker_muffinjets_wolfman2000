local variant = Tracker.ActiveVariantUID

--GLOBALLY LOADED SHIT
Tracker:AddItems("items/items.json")

ScriptHost:LoadScript("scripts/logic.lua")

print("Hi! If you see any error text at all, screenshot it and send it to MuffinJets#7751 on Discord!")


--START WITH ITEMS ONLY
if (string.find(Tracker.ActiveVariantUID, "items_only")) then
    Tracker:AddItems("items/ladxr_settings.json")
    Tracker:AddLayouts("items_only/itemsOnly.json")
    Tracker:AddLayouts("layouts/items_only_broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    ScriptHost:LoadScript("scripts/autotrackingcs.lua")
else if (string.find(Tracker.ActiveVariantUID, "z4r_base")) then
    Tracker:AddItems("items/z4r_settings.json")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/z4r_overworld.json")
    Tracker:AddLocations("locations/z4r_dungeons.json")
    Tracker:AddLayouts("layouts/z4r_tracker.json")
    Tracker:AddLayouts("layouts/z4r_broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    Tracker:AddLayouts("layouts/itemgrids.json")
    ScriptHost:LoadScript("scripts/capturebadge.lua")
    ScriptHost:LoadScript("scripts/autotracking.lua")
else if (string.find(Tracker.ActiveVariantUID, "ladxr_base")) then
    Tracker:AddItems("items/ladxr_settings.json")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/ladxr_overworld.json")
    Tracker:AddLocations("locations/ladxr_dungeons.json")
    Tracker:AddLayouts("layouts/ladxr_tracker.json")
    Tracker:AddLayouts("layouts/ladxr_broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    Tracker:AddLayouts("layouts/itemgrids.json")
    ScriptHost:LoadScript("scripts/autotracking.lua")
else if (string.find(Tracker.ActiveVariantUID, "cave_shuffle")) then
    Tracker:AddItems("items/z4r_settings.json")
    Tracker:AddItems("items/z4r_caveshuffle.json")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/caveshuffle.json")
    Tracker:AddLayouts("cave_shuffle/caves.json")
    Tracker:AddLayouts("layouts/z4r_broadcast.json")
    Tracker:AddLayouts("layouts/cavecapture.json")
    ScriptHost:LoadScript("scripts/capturebadgecs.lua")
    ScriptHost:LoadScript("scripts/autotrackingcs.lua")
else if (string.find(Tracker.ActiveVariantUID, "dungeon_shuffle_z4r")) then
    Tracker:AddItems("items/z4r_settings.json")
    Tracker:AddItems("items/z4r_caveshuffle.json")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/caveshuffle.json")
    Tracker:AddLayouts("z4r_dungeon_shuffle/z4r_dungeon_shuffle.json")
    Tracker:AddLayouts("layouts/z4r_broadcast.json")
    Tracker:AddLayouts("layouts/cavecapture.json")
    ScriptHost:LoadScript("scripts/capturebadgecs.lua")
    ScriptHost:LoadScript("scripts/autotrackingcs.lua")
else if (string.find(Tracker.ActiveVariantUID, "dungeon_shuffle_ladxr")) then
    Tracker:AddItems("items/ladxr_settings.json")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/ladxr_overworld.json")
    Tracker:AddLocations("locations/ladxr_dungeons.json")
    Tracker:AddLayouts("ladxr_dungeon_shuffle/ladxr_dungeon_shuffle.json")
    Tracker:AddLayouts("layouts/ladxr_broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    Tracker:AddLayouts("layouts/itemgrids.json")
    ScriptHost:LoadScript("scripts/autotracking.lua")
end
end
end
end
end
end