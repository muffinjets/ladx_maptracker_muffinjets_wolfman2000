local variant = Tracker.ActiveVariantUID

--GLOBALLY LOADED SHIT
Tracker:AddItems("items/items.json")

ScriptHost:LoadScript("scripts/logic.lua")


--START WITH ITEMS ONLY
if (string.find(Tracker.ActiveVariantUID, "items_only")) then
    print("Loading itemsOnly.json and broadcast.json")
    Tracker:AddLayouts("items_only/itemsOnly.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
else if (string.find(Tracker.ActiveVariantUID, "items_with_keys")) then
    print("Loading itemsOnlyKeys.json and broadcast.json")
    Tracker:AddLayouts("items_with_keys/itemsOnlyKeys.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
else if (string.find(Tracker.ActiveVariantUID, "standard")) then
    print("Loading maps.json, overworld.json, simpledungeons.json, simple.json, and broadcast.json")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/overworld.json")
    Tracker:AddLocations("locations/simpledungeons.json")
    Tracker:AddLayouts("layouts/simple.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
else if (string.find(Tracker.ActiveVariantUID, "advanced")) then
    print("Loading advancedmaps.json, overworld.json, advanceddungons.json, advanced.json, and broadcast.json")
    Tracker:AddMaps("maps/advancedmaps.json")
    Tracker:AddLocations("locations/overworld.json")
    Tracker:AddLocations("locations/advanceddungeons.json")
    Tracker:AddLayouts("layouts/advanced.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
else if (string.find(Tracker.ActiveVariantUID, "cave_shuffle")) then
    print("Loading relevant files for cave shuffle.")
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/caveshuffle.json")
    Tracker:AddLayouts("cave_shuffle/cavesimple.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/cavecapture.json")
end
end
end
end
end