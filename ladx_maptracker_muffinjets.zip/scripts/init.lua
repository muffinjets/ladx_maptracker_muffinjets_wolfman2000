local variant = Tracker.ActiveVariantUID

--GLOBALLY LOADED SHIT
Tracker:AddItems("items/items.json")

ScriptHost:LoadScript("scripts/logic.lua")

Tracker:AddLayouts("layouts/capture.json")


--ADVANCED DUNGEON TRACKING SHIT
if not (string.find(Tracker.ActiveVariantUID, "standard")) then
    Tracker:AddMaps("maps/advancedmaps.json")
    Tracker:AddLocations("locations/overworld.json")
    Tracker:AddLocations("locations/advanceddungeons.json")
    Tracker:AddLayouts("layouts/advanced.json")
    Tracker:AddLayouts("layouts/broadcast.json")
else
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/overworld.json")
    Tracker:AddLocations("locations/simpledungeons.json")
    Tracker:AddLayouts("layouts/tracker.json")
    Tracker:AddLayouts("layouts/broadcast.json")
end