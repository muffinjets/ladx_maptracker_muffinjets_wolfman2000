local variant = Tracker.ActiveVariantUID

--GLOBALLY LOADED SHIT
Tracker:AddItems("items/items.json")

ScriptHost:LoadScript("scripts/logic.lua")

print("Hi! If you see any error text at all, screenshot it and send it to MuffinJets#4665 on Discord!")


--START WITH ITEMS ONLY
if (string.find(Tracker.ActiveVariantUID, "items_only")) then
    Tracker:AddLayouts("items_only/itemsOnly.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    ScriptHost:LoadScript("scripts/autotrackingcs.lua")
else if (string.find(Tracker.ActiveVariantUID, "advanced")) then
    Tracker:AddMaps("maps/advancedmaps.json")
    Tracker:AddLocations("locations/overworld.json")
    Tracker:AddLocations("locations/dungeons.json")
    Tracker:AddLayouts("layouts/tracker.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/capture.json")
    Tracker:AddLayouts("layouts/itemgrids.json")
    ScriptHost:LoadScript("scripts/capturebadge.lua")
    ScriptHost:LoadScript("scripts/autotracking.lua")
else if (string.find(Tracker.ActiveVariantUID, "cave_shuffle")) then
    Tracker:AddMaps("maps/maps.json")
    Tracker:AddLocations("locations/caveshuffle.json")
    Tracker:AddLayouts("cave_shuffle/caves.json")
    Tracker:AddLayouts("layouts/broadcast.json")
    Tracker:AddLayouts("layouts/cavecapture.json")
    ScriptHost:LoadScript("scripts/capturebadgecs.lua")
    ScriptHost:LoadScript("scripts/autotrackingcs.lua")
end
end
end