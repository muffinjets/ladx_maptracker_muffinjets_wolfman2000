Tracker:AddItems("items/items.json")

Tracker:AddMaps("maps/maps.json")

ScriptHost:LoadScript("scripts/logic.lua")

Tracker:AddLocations("locations/overworld.json")
Tracker:AddLocations("locations/advanceddungeons.json")
Tracker:AddLocations("locations/simpledungeons.json")

Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")
Tracker:AddLayouts("layouts/capture.json")

Tracker:AddLayouts("items_only/layouts/tracker.json")